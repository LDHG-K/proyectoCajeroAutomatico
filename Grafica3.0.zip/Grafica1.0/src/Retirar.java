import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Retirar extends JFrame {

	private JPanel contentPane;
	private JTextField txtRetirar;
	private JButton btnRetirar;
	private JButton btnVolver;
	private JTextField txtSaldo;

	

	/**
	 * Create the frame.
	 */
	public Retirar() {
		setTitle("Cajero FIFI");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 283);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Saldo");
		lblNewLabel.setFont(new Font("Tahoma", Font.ITALIC, 16));
		lblNewLabel.setBounds(12, 132, 56, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblCuantoDeseaRetirar = new JLabel("Cuanto desea retirar");
		lblCuantoDeseaRetirar.setHorizontalAlignment(SwingConstants.CENTER);
		lblCuantoDeseaRetirar.setFont(new Font("Tahoma", Font.ITALIC, 14));
		lblCuantoDeseaRetirar.setBounds(12, 53, 131, 33);
		contentPane.add(lblCuantoDeseaRetirar);
		
		txtRetirar = new JTextField();
		txtRetirar.setBounds(166, 59, 228, 22);
		contentPane.add(txtRetirar);
		txtRetirar.setColumns(10);
		
		btnRetirar = new JButton("Retirar");
		btnRetirar.setBounds(12, 194, 97, 25);
		contentPane.add(btnRetirar);
		
		btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnVolver.setBounds(299, 194, 97, 25);
		contentPane.add(btnVolver);
		
		txtSaldo = new JTextField();
		txtSaldo.setColumns(10);
		txtSaldo.setBounds(166, 130, 228, 22);
		contentPane.add(txtSaldo);
	}

}
