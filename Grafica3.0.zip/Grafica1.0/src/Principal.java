import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Principal extends JFrame {

	private JPanel contentPane;
	public static JPasswordField txtClave;
	public static JTextField txtUsuario;

	

	/**
	 * Create the frame.
	 */
	public Principal() {
		setTitle("Cajero FIFI");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 435, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(12, 13, 388, 227);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Cajero FIFI");
		lblNewLabel.setFont(new Font("Tahoma", Font.ITALIC, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(155, 0, 117, 29);
		panel.add(lblNewLabel);
		
		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setBounds(44, 67, 56, 16);
		panel.add(lblUsuario);
		
		JLabel lblClave = new JLabel("Clave");
		lblClave.setBounds(44, 113, 56, 16);
		panel.add(lblClave);
		
		txtClave = new JPasswordField();
		txtClave.setBounds(130, 113, 211, 23);
		panel.add(txtClave);
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(127, 64, 214, 22);
		panel.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);

			}
		});
		btnSalir.setBounds(44, 178, 81, 25);
		panel.add(btnSalir);
		
		// nuevo
		final DataUser data = new DataUser();
        final CajeroPrincipal graf = new CajeroPrincipal();
		
		JButton btnIngresar = new JButton("Ingresar");
		btnIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(data.confirmar() == 1){
					JOptionPane.showMessageDialog(null,"Bienvenido "+ txtUsuario.getText() + " al cajero FIFI");
					graf.setVisible(true);
					dispose();
					
				}else{
					JOptionPane.showMessageDialog(null,"Datos Errados, rectifique el usuario o la contrase�a");
					
					
				}
			}
		});
		btnIngresar.setBounds(275, 178, 81, 25);
		panel.add(btnIngresar);
		
		// Nuevo
        final Recargar recargar = new Recargar();

		JButton btnConsignar = new JButton("Consignar");
		
		btnConsignar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				recargar.setVisible(true);
				dispose();
				
			}
		});
		btnConsignar.setBounds(157, 178, 97, 25);
		panel.add(btnConsignar);
	}
}
