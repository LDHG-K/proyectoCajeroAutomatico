import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Transferencia extends JFrame {

	private JPanel contentPane;
	private JTextField txtCuentaEnvia;
	private JTextField txtCuentaDestino;
	private JTextField textField;

	

	/**
	 * Create the frame.
	 */
	public Transferencia() {
		setTitle("Cajero FIFI");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 487, 381);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNumeroDeCuenta = new JLabel("Numero de cuenta");
		lblNumeroDeCuenta.setFont(new Font("Tahoma", Font.ITALIC, 15));
		lblNumeroDeCuenta.setBounds(23, 50, 125, 16);
		contentPane.add(lblNumeroDeCuenta);
		
		txtCuentaEnvia = new JTextField();
		txtCuentaEnvia.setBounds(248, 48, 192, 22);
		contentPane.add(txtCuentaEnvia);
		txtCuentaEnvia.setColumns(10);
		
		JLabel lblNumeroDeCuenta_1 = new JLabel("Numero de cuenta destinatario");
		lblNumeroDeCuenta_1.setFont(new Font("Tahoma", Font.ITALIC, 15));
		lblNumeroDeCuenta_1.setBounds(23, 136, 214, 16);
		contentPane.add(lblNumeroDeCuenta_1);
		
		txtCuentaDestino = new JTextField();
		txtCuentaDestino.setBounds(250, 134, 190, 22);
		contentPane.add(txtCuentaDestino);
		txtCuentaDestino.setColumns(10);
		
		JLabel lblValorDeLa = new JLabel("Valor de la Transferencia");
		lblValorDeLa.setFont(new Font("Tahoma", Font.ITALIC, 15));
		lblValorDeLa.setBounds(23, 216, 202, 16);
		contentPane.add(lblValorDeLa);
		
		textField = new JTextField();
		textField.setBounds(248, 214, 192, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnTransferir = new JButton("Transferir");
		btnTransferir.setBounds(23, 286, 97, 35);
		contentPane.add(btnTransferir);
		
		JButton btnVolvt = new JButton("Volver");
		btnVolvt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnVolvt.setBounds(343, 286, 97, 35);
		contentPane.add(btnVolvt);
	}

}
