import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CajeroPrincipal extends JFrame {

	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	public CajeroPrincipal() {
		setTitle("Cajero FIFI");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 486, 269);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBienvenido = new JLabel("Bienvenido al cajero FIFI");
		lblBienvenido.setHorizontalAlignment(SwingConstants.CENTER);
		lblBienvenido.setFont(new Font("Tahoma", Font.ITALIC, 20));
		lblBienvenido.setBounds(0, 0, 468, 29);
		contentPane.add(lblBienvenido);
		
        final Saldo graf = new Saldo();

		JButton btnConsultarSaldo = new JButton("Consultar saldo");
		btnConsultarSaldo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				graf.setVisible(true);

			}
		});
		btnConsultarSaldo.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnConsultarSaldo.setBounds(12, 79, 118, 33);
		contentPane.add(btnConsultarSaldo);
		
		JButton btnConsultarsaldo_1 = new JButton("Salir");
		btnConsultarsaldo_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnConsultarsaldo_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnConsultarsaldo_1.setBounds(12, 164, 118, 33);
		contentPane.add(btnConsultarsaldo_1);
		
        final Retirar retir = new Retirar();

		JButton btnRetirar = new JButton("Retirar");
		btnRetirar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				retir.setVisible(true);
			}
		});
		btnRetirar.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnRetirar.setBounds(338, 164, 118, 33);
		contentPane.add(btnRetirar);
		
        final Transferencia trans = new Transferencia();

		JButton btnTransferencia = new JButton("Transferencia");
		btnTransferencia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				trans.setVisible(true);

			}
		});
		btnTransferencia.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnTransferencia.setBounds(338, 79, 118, 33);
		contentPane.add(btnTransferencia);
	}
}
