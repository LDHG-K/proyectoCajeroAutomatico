

public class DataUser {

   String usuario = "";
   String contrase�a = "";
	public DataUser() {

	}

   public int confirmar(){
	   usuario = Principal.txtUsuario.getText();
	   contrase�a = Principal.txtClave.getText();
	   
	   if(usuario != null && contrase�a != null){
		   return 1;
	   }else{
		   return 0;
	   }
		  
   }
	
	
}
