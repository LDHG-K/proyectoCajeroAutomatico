

import java.awt.EventQueue;

public class PrincipalVisible {

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	
	Principal contra = new Principal();
    
	contra.setVisible(true);
				
		
		
	}
	
}
