import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Recargar extends JFrame {

	private JPanel contentPane;
	private JTextField txtNumeroCuenta;
	private JTextField txtValorIngresado;
	private JButton btnVolver;
	private JButton btnIngresar;

	

	/**
	 * Create the frame.
	 */
	public Recargar() {
		setTitle("Cajero FIFI");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 460, 256);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNumeoDeCuenta = new JLabel("Numeo de cuenta");
		lblNumeoDeCuenta.setFont(new Font("Tahoma", Font.ITALIC, 16));
		lblNumeoDeCuenta.setBounds(12, 42, 136, 16);
		contentPane.add(lblNumeoDeCuenta);
		
		JLabel lblValorAIngresar = new JLabel("Valor a ingresar");
		lblValorAIngresar.setFont(new Font("Tahoma", Font.ITALIC, 16));
		lblValorAIngresar.setBounds(12, 124, 136, 16);
		contentPane.add(lblValorAIngresar);
		
		txtNumeroCuenta = new JTextField();
		txtNumeroCuenta.setBounds(193, 40, 221, 22);
		contentPane.add(txtNumeroCuenta);
		txtNumeroCuenta.setColumns(10);
		
		txtValorIngresado = new JTextField();
		txtValorIngresado.setColumns(10);
		txtValorIngresado.setBounds(193, 122, 221, 22);
		contentPane.add(txtValorIngresado);
		
		btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnVolver.setBounds(12, 171, 97, 25);
		contentPane.add(btnVolver);
		
		btnIngresar = new JButton("Ingresar");
		btnIngresar.setBounds(317, 171, 97, 25);
		contentPane.add(btnIngresar);
	}

}
