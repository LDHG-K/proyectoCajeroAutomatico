package clientes;

import interfaces.IDto;

import java.io.Serializable;
import java.math.BigDecimal;

public class clientes implements IDto, Serializable
{
    //-------------------------------
    private static final long serialVersionUID = 9891209481243L;
    private Integer idCliente ;
    private Integer clave;
    private Integer identificacion;
    private String nombre;
    private String apellido;
    private Integer cuenta;
    private BigDecimal saldo;
    private Integer tipoIdentificacion;
    private Integer tipoCuenta;
    private Integer estadoCuenta;

    //--------------------------------
 public clientes (Integer idcliente, Integer clave, Integer identificacion, String nombre, String  apellido, Integer cuenta, BigDecimal saldo, Integer tipoIdentificacion, Integer tipoCuenta, Integer estadoCuenta){

     this.idCliente = idcliente ;
     this.clave = clave;
     this.identificacion = identificacion;
     this.apellido = apellido;
     this.nombre = nombre;
     this.cuenta = cuenta;
     this.saldo = saldo;
     this.tipoIdentificacion=tipoIdentificacion;
     this.tipoCuenta= tipoCuenta;
     this.estadoCuenta=estadoCuenta;
 }
    public clientes (Integer idCliente) {this.idCliente = idCliente;}
     public clientes () { }
    //-------------------------------------

    public Integer getIdCliente() {
        return this.idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public Integer getClave() {
        return clave;
    }

    public void setClave(Integer clave) {
        this.clave = clave;
    }

    public Integer getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(Integer identificacion) {
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public Integer getCuenta() {
        return cuenta;
    }

    public void setCuenta(Integer cuenta) {
        this.cuenta = cuenta;
    }

    public BigDecimal getSaldo() {
        return saldo;
    }

    public void setSaldo(BigDecimal saldo) {
        this.saldo = saldo;
    }

    public Integer getTipoIdentificacion() {
        return tipoIdentificacion;
    }

    public void setTipoIdentificacion(Integer tipoIdentificacion) {
        this.tipoIdentificacion = tipoIdentificacion;
    }

    public Integer getTipoCuenta() {
        return tipoCuenta;
    }

    public void setTipoCuenta(Integer tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    public Integer getEstadoCuenta() {
        return estadoCuenta;
    }

    public void setEstadoCuenta(Integer estadoCuenta) {
        this.estadoCuenta = estadoCuenta;
    }

    //--------------------------------------
    @Override
    public String insert() {
        return "insert into clientes values ("+getIdCliente()+","+getIdentificacion()+","+getNombre()+","+getApellido()+","+getCuenta()+","+getSaldo()+","+
                getTipoIdentificacion()+","+getTipoCuenta()+","+getEstadoCuenta()+");";
    }



    @Override
    public String update() {

     String temp = "update clientes set nombres = '" + getNombre() + "' Where id_Cliente =  '" + getIdCliente() + "' ;" +
                   "update clientes set apellidos = '" + getApellido() + "' Where id_Cliente =  '" + getIdCliente() + "' ;" +
                   "update clientes set identificacion = '" + getIdentificacion() + "' Where id_Cliente =  '" + getIdCliente() + "' ;" +
                   "update clientes set estado_tipo = '" + getEstadoCuenta() + "' Where id_Cliente =  '" + getIdCliente() + "' ;"  +
                   "update clientes set tipo_cuenta = '" + getTipoCuenta() + "' Where id_Cliente =  '" + getIdCliente() + "' ;" +
                   "update clientes set clave = '" + getClave() + "' Where id_Cliente =  '" + getIdCliente() + "' ;";

     return  temp;

    }


    public String updateNombre() {


        String temp = "update clientes set nombres = '" + getNombre() + "' Where id_Cliente =  '" + getIdCliente() + "' ;" ;

        return  temp;

    }

    public String updateApellido() {


        String temp = "update clientes set apellidos = '" + getApellido() + "' Where id_Cliente =  '" + getIdCliente() + "' ;" ;

        return  temp;

    }

    public String updateIdentificacion() {


        String temp = "update clientes set identificacion = '" + getIdentificacion() + "' Where id_Cliente =  '" + getIdCliente() + "' ;" ;

        return  temp;

    }

    public String updateCuantaEstado() {


        String temp = "update clientes set estado_tipo = '" + getEstadoCuenta() + "' Where id_Cliente =  '" + getIdCliente() + "' ;" ;

        return  temp;

    }

    public String updateTipoCuenta() {


        String temp = "update clientes set tipo_cuenta = '" + getTipoCuenta() + "' Where id_Cliente =  '" + getIdCliente() + "' ;" ;

        return  temp;

    }

    public String updateClave() {


        String temp = "update clientes set clave = '" + getClave() + "' Where id_Cliente =  '" + getIdCliente() + "' ;" ;

        return  temp;

    }

    public String updateSaldo(String transferencia) {

        BigDecimal saldoActual = new BigDecimal(String.valueOf(getSaldo()));

        BigDecimal trans = new BigDecimal(String.valueOf(transferencia));

        BigDecimal nuevosal = saldoActual.add(trans);

        String temp = "update clientes set saldo = '" + nuevosal + "' Where id_Cliente =  '" + getIdCliente() + "' ;" ;

        return  temp;

    }


    @Override
    public String delete()
    {
        return "DELETE * from  clientes WHERE id_cliente = " + getIdCliente() + ";";
    }

    @Override
    public String findAll()
    {
        return "select * from clientes";
    }

    @Override
    public String findById()
    {
        return "select * from clientes where id = "+ getIdCliente();
    }
//-----------------------------------------

    @Override
    public String toString() {
        return "clientes{" +
                "idCliente=" + idCliente +
                ", clave=" + clave +
                ", identificacion=" + identificacion +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", cuenta=" + cuenta +
                ", saldo=" + saldo +
                ", tipoIdentificacion=" + tipoIdentificacion +
                ", tipoCuenta=" + tipoCuenta +
                ", estadoCuenta=" + estadoCuenta +
                '}';
    }
}
