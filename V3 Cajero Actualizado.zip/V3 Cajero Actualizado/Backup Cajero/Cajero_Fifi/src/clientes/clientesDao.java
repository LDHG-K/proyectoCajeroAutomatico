package clientes;

import interfaces.abstractDao;

public class clientesDao  extends abstractDao<clientes>
{


    public clientesDao()
    {
        super(clientes.class);
    }

}
