package interfazGrafica;

import clientes.*;
import interfaces.abstractDao;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
public class Retirar extends JFrame
{

	private JPanel contentPane;
	private JTextField txtRetirar;
	private JButton btnRetirar;
	private JButton btnVolver;
	private JTextField txtSaldo;
	private JLabel lblSacarFondos;

	

	/**
	 * Create the frame.
	 */
	public Retirar()
	{
		setTitle("RETIROS");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 283);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Saldo Actual:");
		lblNewLabel.setFont(new Font("Tlwg Typist", Font.BOLD | Font.ITALIC, 16));
		lblNewLabel.setBounds(34, 77, 131, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblCuantoDeseaRetirar = new JLabel("Cuanto desea retirar:");
		lblCuantoDeseaRetirar.setHorizontalAlignment(SwingConstants.CENTER);
		lblCuantoDeseaRetirar.setFont(new Font("Tlwg Typist", Font.BOLD | Font.ITALIC, 16));
		lblCuantoDeseaRetirar.setBounds(27, 117, 216, 36);
		contentPane.add(lblCuantoDeseaRetirar);
		
		txtRetirar = new JTextField();
		txtRetirar.setBounds(247, 124, 148, 22);
		contentPane.add(txtRetirar);
		txtRetirar.setColumns(10);
		
		btnRetirar = new JButton("Retirar");
		btnRetirar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{

				clientesDao clientesDaoObject = new clientesDao();

				BigDecimal dineroARetirar = new BigDecimal (txtRetirar.getText());

				BigDecimal dineroActual = abstractDao.saldo;

				if (dineroARetirar.compareTo(dineroActual)==-1)
				{
					dineroActual = dineroActual.subtract(dineroARetirar);


					clientes clientesObject = new clientes(Login.idCliente, abstractDao.clave, abstractDao.identificacion, abstractDao.nombres, abstractDao.apellidos,
							String.valueOf(abstractDao.cuenta), dineroActual, abstractDao.tipoIdentificacion, abstractDao.tipoCuenta, abstractDao.estadoTipo);

					clientesDaoObject.update(clientesObject);

					JOptionPane.showMessageDialog(null, "Ha retirado Correctamente: " + txtRetirar.getText() + " Su nuevo saldo es: "
							+ dineroActual);

					dispose();
				}
				else {
					JOptionPane.showMessageDialog(null, "Fondos Insuficientes");
				}
			}
		});





		btnRetirar.setBounds(68, 194, 97, 25);
		contentPane.add(btnRetirar);

		
		btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				dispose();
			}
		});
		btnVolver.setBounds(256, 194, 97, 25);
		contentPane.add(btnVolver);
		
		txtSaldo = new JTextField();
		txtSaldo.setEditable(false);
		txtSaldo.setEnabled(false);
		txtSaldo.setColumns(10);
		txtSaldo.setBounds(168, 74, 131, 22);
		contentPane.add(txtSaldo);

		txtSaldo.setText(String.valueOf(abstractDao.saldo));
		
		lblSacarFondos = new JLabel("Extraer Fondos:");
		lblSacarFondos.setHorizontalAlignment(SwingConstants.CENTER);
		lblSacarFondos.setFont(new Font("Yrsa Medium", Font.BOLD, 30));
		lblSacarFondos.setBounds(51, 12, 337, 29);
		contentPane.add(lblSacarFondos);
	}

}
