package interfazGrafica;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();

		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.setBounds(100, 100, 450, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		final Login principal = new Login();
		JButton btnIngresar = new JButton("LOGIN");
		btnIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				principal.setVisible(true);
				dispose();
			}
		});
		btnIngresar.setFont(new Font("TlwgTypewriter", Font.BOLD, 13));
		btnIngresar.setBounds(12, 85, 157, 45);
		frame.getContentPane().add(btnIngresar);
		
		// Nuevo
        final Consignar recargar = new Consignar();
		JButton btnSalir = new JButton("CONSIGNACIONES");
		btnSalir.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				recargar.setVisible(true);
				dispose();
			}
		});
		btnSalir.setFont(new Font("TlwgTypewriter", Font.BOLD, 13));
		btnSalir.setBounds(259, 85, 157, 45);
		frame.getContentPane().add(btnSalir);
		
		JLabel lblBienvenido = new JLabel("BIENVENIDO");
		lblBienvenido.setFont(new Font("Yrsa Medium", Font.BOLD, 26));
		lblBienvenido.setBounds(143, 29, 223, 28);
		frame.getContentPane().add(lblBienvenido);
	}
}
