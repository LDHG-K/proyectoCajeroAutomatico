package cliente;

import ServicioCliente.ServicioCliente;
import clientes.clientes;
import clientes.clientesDao;
import interfaces.IDto;
import interfazGrafica.Login;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.math.BigDecimal;
import java.net.Socket;


public class cliente
{
    private Socket cliente;
    private DataOutputStream out;
    private ObjectInputStream ois;

    private int puerto = 2027;
    private String host = "localhost";


    public static void main(String[] args)
    {
        new cliente("nada");
    }
    public cliente(String sql)
    {
        try
        {
            cliente = new Socket(host,puerto);
            this.out = new DataOutputStream(cliente.getOutputStream());
            this.ois = new ObjectInputStream(cliente.getInputStream());




            clientes hola = new clientes(3);
            getOneObject( clientes.class.getName() + "#" + hola.findById());



            //tiposCuentasDao cuentasDao = new tiposCuentasDao();
            //tiposCuentas cuentas = new tiposCuentas(1);
            //System.out.println(cuentas.getNombre());




           getOneObject(clientes.class.getName() + "#update clientes set saldo=999333 where cuenta = '1040';");



            this.ois.close();
            this.out.close();


        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

   ServicioCliente clienteService = new ServicioCliente(Login.idCliente);
   clientesDao clientesDaoObject = new clientesDao();
   clientes clientesObject = new clientes();


/*
    public void agregarDinero(BigDecimal dineroPositivo)
    {

    BigDecimal dineroActual = new BigDecimal (clienteService.getSaldo());

    dineroActual = dineroActual.add(dineroPositivo);

        clientes clientesObject = new clientes(Principal.idCliente, abstractDao.clave, abstractDao.identificacion,abstractDao.nombres, abstractDao.apellidos,
                abstractDao.cuenta, dineroActual,abstractDao.tipoIdentificacion,abstractDao.tipoCuenta, abstractDao.estadoTipo);

    clientesDaoObject.update(clientesObject);


    }

 */

    public void consignarDinero(BigDecimal dineroPositivo, String cuenta)
    {

        getOneObject(clientes.class.getName() + "#" + "update clientes set saldo=" + dineroPositivo + "where cuenta = '"+ cuenta +"';");


    }

    public void restarDinero(BigDecimal dineroNegativo)
    {

    }






    public void getOneObject(String sql)
    {
        try
        {
            this.out.writeUTF(sql);
            this.out.flush();

            IDto response = (IDto) ois.readObject();

            System.out.println(response);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    
}
