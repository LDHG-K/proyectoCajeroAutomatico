package transacciones;

import interfaces.abstractDao;

public class transaccionesDao extends abstractDao<transacciones>
{
    public transaccionesDao()
    {

        super(transacciones.class);
    }
}
