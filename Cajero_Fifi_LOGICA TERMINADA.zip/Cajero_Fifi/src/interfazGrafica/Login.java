package interfazGrafica;

import ServicioCliente.ServicioCliente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame {

	private JPanel contentPane;
	public static JPasswordField txtClave;
	public static JTextField txtUsuario;
	public static Integer idCliente;

	

	/**
	 * Create the frame.
	 */
	public Login()
	{
		setBackground(Color.WHITE);
		setTitle("FIFI BANK");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 400, 270);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(27, 22, 351, 192);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblUsuario = new JLabel("ID Cliente:");
		lblUsuario.setBounds(30, 51, 79, 16);
		panel.add(lblUsuario);
		
		JLabel lblClave = new JLabel("Clave:");
		lblClave.setBounds(30, 97, 56, 16);
		panel.add(lblClave);
		
		txtClave = new JPasswordField();
		txtClave.setBounds(127, 96, 70, 23);
		panel.add(txtClave);
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(127, 50, 190, 22);
		panel.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.setFont(new Font("TlwgTypewriter", Font.BOLD, 13));
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);

			}
		});
		btnSalir.setBounds(60, 155, 98, 25);
		panel.add(btnSalir);
		
		final CajeroPrincipal graf = new CajeroPrincipal();
		
		JButton btnIngresar = new JButton("Ingresar");
		btnIngresar.setFont(new Font("TlwgTypewriter", Font.BOLD, 13));
		btnIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				if(txtUsuario.getText().length() != 0 && txtClave.getPassword().length != 0)
				{
					char [] claveEncriptada = txtClave.getPassword();

					Integer usuario = Integer.parseInt(txtUsuario.getText());
					idCliente=usuario;

					ServicioCliente cliente = new ServicioCliente(usuario);

					if(cliente.loginComprobacion(usuario,claveEncriptada))
					{
						graf.setVisible(true);
						dispose();
					}
					else
						{
							JOptionPane.showMessageDialog(null,"Usuario o Clave Invalidos");
						}
				}

				else
				{
					JOptionPane.showMessageDialog(null,"Usuario o Clave Vacio");
				}
			}
		});
		btnIngresar.setBounds(189, 155, 98, 25);
		panel.add(btnIngresar);
		
		// Nuevo
        final Consignar recargar = new Consignar();
		
		JLabel lblNewLabel = new JLabel("Inicie Sesion");
		lblNewLabel.setBounds(128, 0, 143, 29);
		contentPane.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Yrsa Medium", Font.BOLD, 26));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	}
}
