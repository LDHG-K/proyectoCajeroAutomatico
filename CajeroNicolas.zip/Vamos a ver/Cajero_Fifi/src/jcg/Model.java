package jcg;

import javax.swing.table.DefaultTableModel;

/**
 * @author ashraf
 *
 */
@SuppressWarnings("serial")
public class Model extends DefaultTableModel {

	public Model() {
		super(Constants.DATA_CLIENTE, Constants.TABLE_ClIENTE);
	}

}
