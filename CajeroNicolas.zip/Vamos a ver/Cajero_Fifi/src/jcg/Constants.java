package jcg;

/**
 * @author ashraf_sarhan
 * 
 */
public class Constants {


	// Tipo:Cuenta
	public static final Object[] TABLE_ClIENTE = { "Id_Cliente", "Identificacion","Nombres","Apellidos","Cuenta","Saldo","Tipo_Identificacion","Tipo_Cuenta","Estado_tipo"};

	public static final Object[][] DATA_CLIENTE = {
			{ "1", 1005840031,"Luis","Herrera",1040, 1200000.00, 1,2,1},
			{ "2", 1004321120,"Jhon","Bravp",1243, 90000.00, 1,2,1 },
			{ "3", 1004321120,"Laura","Paramo",4321, 120000.00, 2,2,1},
			{ "4", 1908000012,"Nicolas","Perez",3521, 110000.00, 2,1,2}};
	
}
