package db;

import interfaces.*;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.LinkedList;
import java.util.List;


public class ConexionSocket {

    private static ConexionSocket conexionSocket = null;

    private ObjectInputStream ois;

    private ObjectOutputStream oos;

    private ConexionSocket()
    {
        try {

            int puerto = 2027;
            String host = "localhost";
            Socket cliente = new Socket(host,puerto);
            this.oos = new ObjectOutputStream(cliente.getOutputStream());
            this.ois = new ObjectInputStream(cliente.getInputStream());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ConexionSocket getInstance()
    {
        if (conexionSocket == null) {
            conexionSocket = new ConexionSocket();
        }
        return conexionSocket;
    }

    public IDto executeQuerySingle(DataSocket dataSocket)
    {
        IDto response = null;
        try {

            SingleResult singleResult = new SingleResult(dataSocket);
            this.oos.writeObject(singleResult);
            this.oos.flush();
            response = (IDto) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

    public List<IDto> executeQueryMultiple(DataSocket dataSocket)
    {
        List<IDto> response = new LinkedList<>();

        try {

            MultipleResult multipleResult = new MultipleResult(dataSocket);
            this.oos.writeObject(multipleResult);
            this.oos.flush();
            response = (List<IDto>) ois.readObject();

        } catch (Exception e) {
            e.printStackTrace();
        }


        return response;
    }

    public Boolean executeUpdate(DataSocket dataSocket)
    {
        Boolean response = false;

        try {
            ExecuteUpdate executeUpdate = new ExecuteUpdate(dataSocket);
            this.oos.writeObject(executeUpdate);
            this.oos.flush();
            response = (Boolean) ois.readObject();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return response;
    }

    public String disconnectSocket(DataSocket dataSocket)
    {
        String response = "";

        try {

            DisconnetSocket disconnetSocket = new DisconnetSocket(dataSocket);
            this.oos.writeObject(disconnetSocket);
            this.oos.flush();
            response =(String)ois.readObject();

        }catch(Exception e)
        {
            e.printStackTrace();
        }


        return response;
    }

}