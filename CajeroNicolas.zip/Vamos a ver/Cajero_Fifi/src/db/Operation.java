package db;

public enum  Operation {

    EXECUTE_UPDATE("execute:update"),

    SINGLE_RESULT("single:result"),

    MULTIPLE_RESULT("multiple:result"),

    DISCONNECT_SOCKET("disconnet:socket");

    private String operation;

    Operation(String operation) { this.operation = operation;}

    public String getOperation(){ return operation;}

}
