package InterfazGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CuentaDebito extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CuentaDebito frame = new CuentaDebito();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CuentaDebito() {
		setTitle("Cajero automatico \"DEBITO\"");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 433, 518);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 128));
		contentPane.setForeground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0));
		panel.setBounds(28, 28, 351, 319);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 128));
		panel_1.setBounds(26, 25, 296, 266);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 0, 0));
		panel_2.setBounds(0, 63, 83, 36);
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		String usuario = "";
		usuario = InterfazPrincipal.txtUsuario.getText();
		JLabel lblUsuarioLa = new JLabel(usuario);
		lblUsuarioLa.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsuarioLa.setForeground(Color.WHITE);
		lblUsuarioLa.setFont(new Font("Tahoma", Font.ITALIC, 15));
		lblUsuarioLa.setBackground(Color.WHITE);
		lblUsuarioLa.setBounds(12, 0, 56, 34);
		panel_2.add(lblUsuarioLa);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(0, 0, 0));
		panel_3.setBounds(71, 0, 163, 43);
		panel_1.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblCajeroAutomatico = new JLabel("Cajero automatico");
		lblCajeroAutomatico.setHorizontalAlignment(SwingConstants.CENTER);
		lblCajeroAutomatico.setBounds(0, 13, 163, 19);
		panel_3.add(lblCajeroAutomatico);
		lblCajeroAutomatico.setForeground(Color.WHITE);
		lblCajeroAutomatico.setFont(new Font("Tahoma", Font.ITALIC, 15));
		
		JButton btnNewButton_2 = new JButton("Retirar dinero");
		btnNewButton_2.setBounds(225, 360, 154, 25);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Hacer transferencia");
		btnNewButton_3.setBounds(225, 398, 154, 25);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Salir");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnNewButton_4.setBounds(22, 436, 357, 25);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton = new JButton("Consultar cuenta");
		btnNewButton.setBounds(22, 398, 154, 25);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Consultar saldo");
		btnNewButton_1.setBounds(22, 360, 154, 25);
		contentPane.add(btnNewButton_1);
	}

}
