package InterfazGrafica;

public class DataUser {

   String usuario = "";
   String contrase�a = "";
	public DataUser() {

	}

   public int confirmar(){
	   usuario = InterfazPrincipal.txtUsuario.getText();
	   contrase�a = InterfazPrincipal.txtContrase�a.getText();
	   
	   if(usuario != null && contrase�a != null){
		   return 1;
	   }else{
		   return 0;
	   }
		  
   }
	
	
}
