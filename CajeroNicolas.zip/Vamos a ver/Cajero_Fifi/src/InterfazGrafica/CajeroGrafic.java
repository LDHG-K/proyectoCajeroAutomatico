package InterfazGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CajeroGrafic extends JFrame {

	private JPanel contentPane;

	
	public CajeroGrafic() {
		setTitle("Datos usuario");
		setBackground(new Color(0, 0, 0));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 514, 452);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(29, 30, 437, 348);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNombre = new JLabel("Usuario");
		lblNombre.setForeground(new Color(255, 255, 255));
		lblNombre.setBounds(12, 93, 56, 16);
		panel.add(lblNombre);
		lblNombre.setFont(new Font("Tahoma", Font.ITALIC, 15));
		
		JComboBox estado = new JComboBox();
		estado.setBounds(172, 147, 98, 22);
		panel.add(estado);
		estado.setModel(new DefaultComboBoxModel(new String[] {"ACTIVO", "INACTIVO", "CONGELADO"}));
		
		JLabel lblEstadoDeLa = new JLabel("Estado de la cuenta");
		lblEstadoDeLa.setForeground(new Color(255, 255, 255));
		lblEstadoDeLa.setBounds(12, 149, 135, 16);
		panel.add(lblEstadoDeLa);
		lblEstadoDeLa.setFont(new Font("Tahoma", Font.ITALIC, 15));
		
		JLabel lblTipoDeDocumento = new JLabel("Tipo de documento");
		lblTipoDeDocumento.setForeground(new Color(255, 255, 255));
		lblTipoDeDocumento.setBounds(12, 203, 135, 16);
		panel.add(lblTipoDeDocumento);
		lblTipoDeDocumento.setFont(new Font("Tahoma", Font.ITALIC, 15));
		
		JComboBox documeto = new JComboBox();
		documeto.setBounds(172, 201, 98, 22);
		panel.add(documeto);
		documeto.setModel(new DefaultComboBoxModel(new String[] {"Cedula", "Pasaporte"}));
		
		JComboBox cuenta = new JComboBox();
		cuenta.setBounds(172, 252, 98, 22);
		panel.add(cuenta);
		cuenta.setModel(new DefaultComboBoxModel(new String[] {"Ahorros ", "Debito"}));
		
		JLabel lblTipoDeCuenta = new JLabel("Tipo de cuenta");
		lblTipoDeCuenta.setForeground(new Color(255, 255, 255));
		lblTipoDeCuenta.setBounds(12, 254, 111, 16);
		panel.add(lblTipoDeCuenta);
		lblTipoDeCuenta.setFont(new Font("Tahoma", Font.ITALIC, 15));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 0));
		panel_1.setBounds(100, 0, 247, 43);
		panel.add(panel_1);
		
		JLabel lblNewLabel = new JLabel("Cajero Automatico");
		panel_1.add(lblNewLabel);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.ITALIC, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		JButton btnIngresar = new JButton("Ingresar");
		btnIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (estado.getSelectedItem().equals("ACTIVO"))
				{
					if(documeto.getSelectedItem().equals("Cedula")){
						if(cuenta.getSelectedItem().equals("Ahorros"))
						{
							Cuenta contra = new Cuenta();
						    
							contra.setVisible(true);
							
						}else if(cuenta.getSelectedItem().equals("Debito"))
						{
                            
							CuentaDebito contra = new CuentaDebito();
						    
							contra.setVisible(true);
						}
					}
				}
				
			}
		});
		btnIngresar.setBounds(315, 310, 97, 25);
		panel.add(btnIngresar);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				System.exit(0);

			}
		});
		btnSalir.setBounds(12, 310, 97, 25);
		panel.add(btnSalir);
		
		String usuario = "";
		usuario = InterfazPrincipal.txtUsuario.getText();
		JLabel lblUsuarioLa = new JLabel(usuario);
		lblUsuarioLa.setForeground(new Color(255, 255, 255));
		lblUsuarioLa.setFont(new Font("Tahoma", Font.ITALIC, 15));
		lblUsuarioLa.setBounds(172, 93, 98, 17);
		panel.add(lblUsuarioLa);
	}
}
