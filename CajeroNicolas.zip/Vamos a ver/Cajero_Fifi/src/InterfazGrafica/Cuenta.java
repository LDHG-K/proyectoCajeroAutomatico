package InterfazGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Window.Type;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Cuenta extends JFrame {

	private JPanel contentPane;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JPanel panel_1;
	private JTextField textField;
	private JPanel panel_3;
	private JLabel lblCajeroAutomatico;
	private JButton btnNewButton_4;
	private JPanel panel_2;
	private JLabel lblUsuarioLa;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cuenta frame = new Cuenta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cuenta() {
		setTitle("Cajero automatico \"AHORROS\"\r\n");
		setForeground(Color.YELLOW);
		setBackground(Color.YELLOW);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 440, 467);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0));
		panel.setBounds(31, 13, 361, 288);
		contentPane.add(panel);
		panel.setLayout(null);
		
		panel_1 = new JPanel();
		panel_1.setBounds(24, 24, 305, 236);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 0, 0));
		panel_2.setBounds(0, 44, 93, 34);
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		String usuario = "";
		usuario = InterfazPrincipal.txtUsuario.getText();
		
		lblUsuarioLa = new JLabel(usuario);
		lblUsuarioLa.setHorizontalAlignment(SwingConstants.CENTER);
		lblUsuarioLa.setBackground(new Color(255, 255, 255));
		lblUsuarioLa.setForeground(new Color(255, 255, 255));
		lblUsuarioLa.setFont(new Font("Tahoma", Font.ITALIC, 15));
		lblUsuarioLa.setBounds(0, 0, 93, 34);
		panel_2.add(lblUsuarioLa);
		
		panel_3 = new JPanel();
		panel_3.setBounds(45, 0, 236, 31);
		panel_1.add(panel_3);
		panel_3.setBackground(new Color(0, 0, 0));
		
		lblCajeroAutomatico = new JLabel("Cajero automatico");
		lblCajeroAutomatico.setFont(new Font("Tahoma", Font.ITALIC, 15));
		lblCajeroAutomatico.setForeground(new Color(255, 255, 255));
		panel_3.add(lblCajeroAutomatico);
		
		textField = new JTextField();
		textField.setBackground(new Color(0, 0, 128));
		textField.setBounds(0, 0, 305, 236);
		panel_1.add(textField);
		textField.setColumns(10);
		
		btnNewButton = new JButton("Consultar cuenta");
		btnNewButton.setBounds(31, 352, 154, 25);
		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("Consultar saldo");
		btnNewButton_1.setBounds(31, 314, 154, 25);
		contentPane.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("Retirar dinero");
		btnNewButton_2.setBounds(238, 314, 154, 25);
		contentPane.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("Hacer transferencia");
		btnNewButton_3.setBounds(238, 352, 154, 25);
		contentPane.add(btnNewButton_3);
		
		btnNewButton_4 = new JButton("Salir");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);

			}
		});
		btnNewButton_4.setBounds(31, 390, 361, 25);
		contentPane.add(btnNewButton_4);
	}
}
