package InterfazGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import com.jgoodies.forms.factories.DefaultComponentFactory;

import sun.print.resources.serviceui;

import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Panel;
import java.awt.Label;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.GridLayout;
import javax.swing.JTextPane;
import java.awt.FlowLayout;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;

public class InterfazPrincipal extends JFrame {

	private JPanel contentPane;
	public static JPasswordField txtContrase�a;
	public static JTextField txtUsuario;


	/**
	 * Create the frame.
	 */
	public InterfazPrincipal() {
		setTitle("Ingreso usuarios");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 502, 337);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setForeground(Color.BLUE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 128));
		panel.setBounds(24, 19, 431, 246);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 0));
		panel_1.setBounds(95, 0, 235, 44);
		panel.add(panel_1);
		
		JLabel lblCajeroAuntomatico = DefaultComponentFactory.getInstance().createTitle("Cajero Auntomatico");
		panel_1.add(lblCajeroAuntomatico);
		lblCajeroAuntomatico.setBackground(Color.LIGHT_GRAY);
		lblCajeroAuntomatico.setForeground(new Color(255, 255, 255));
		lblCajeroAuntomatico.setHorizontalAlignment(SwingConstants.CENTER);
		lblCajeroAuntomatico.setFont(new Font("Times New Roman", Font.ITALIC, 20));
		
		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setBounds(80, 64, 91, 24);
		panel.add(lblUsuario);
		lblUsuario.setForeground(new Color(255, 255, 255));
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(165, 65, 201, 22);
		panel.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a");
		lblContrasea.setBounds(80, 144, 78, 16);
		panel.add(lblContrasea);
		lblContrasea.setForeground(new Color(255, 255, 255));
		
		txtContrase�a = new JPasswordField();
		txtContrase�a.setBounds(165, 141, 201, 22);
		panel.add(txtContrase�a);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(80, 196, 97, 25);
		panel.add(btnCancelar);
		JButton btnIngresar = new JButton("Ingresar");
		btnIngresar.setBounds(269, 196, 97, 25);
		panel.add(btnIngresar);
		// vamos a ver la union
		final DataUser data = new DataUser();
        final CajeroGrafic graf = new CajeroGrafic();
		
		btnIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				if(data.confirmar() == 1){
					JOptionPane.showMessageDialog(null,"Bienvenido "+ txtUsuario.getText() + " al cajero");
					graf.setVisible(true);
					dispose();
					
				}else{
					JOptionPane.showMessageDialog(null,"Datos Errados, rectifique el usuario o la contrase�a");
					
					
				}
			}
		});
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
	}
}
