package InterfazGrafica;

import java.awt.EventQueue;

public class Principal {

	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
	
	InterfazPrincipal contra = new InterfazPrincipal();
    
	contra.setVisible(true);
				
		
		
	}
	
}
