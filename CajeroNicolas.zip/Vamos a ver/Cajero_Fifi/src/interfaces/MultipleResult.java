package interfaces;

import db.DataSocket;
import servidor.ExecuteSql;

public class MultipleResult extends RequestSocket{


    public MultipleResult (DataSocket request){
        super(request);
    }



    public boolean executeRequest(){
        try{
            Class classIDto = Class.forName(request.getEntityClass().getName());
            ExecuteSql<IDto> executeSql = new ExecuteSql<IDto>(classIDto);
            IDto response = (IDto) executeSql.getManyResults(request.getSql());
            oos.writeObject(response);

        } catch (Exception e){

            e.printStackTrace();
        }
        return true;
    }


}
