package interfaces;

import db.DataSocket;
import servidor.ExecuteSql;

public class ExecuteUpdate extends RequestSocket {

    public  ExecuteUpdate(DataSocket request) {
        super(request);
    }



    @Override
    public boolean executeRequest() {
        boolean response = false;
        try {
            Class classIDto = Class.forName(request.getEntityClass().getName());
            ExecuteSql<IDto> executeSql = new ExecuteSql<IDto>(classIDto);
            response = executeSql.getExecuteUpdate(request.getSql()); // revisar xd
            oos.writeObject(response);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

}