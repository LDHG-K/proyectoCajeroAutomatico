package interfaces;

import db.Conexion;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


public abstract class  AbstractDao<T extends IDto> implements IDao {

    protected Conexion con;
    private Class<T> entityClass;

    public AbstractDao(Class<T> entityClass) {
        con = Conexion.getInstance();
        this.entityClass = entityClass;
    }

    @Override
    public boolean insert(IDto dto) {
        return con.executeUpdate(dto.insert()) > 0;
    }

    @Override
    public boolean update(IDto dto) {
        return con.executeUpdate(dto.update()) > 0;
    }

    @Override
    public boolean delete(IDto dto) {
        return con.executeUpdate(dto.delete()) > 0;
    }

    public IDto getById(IDto dto) {
        T newObject = newObject();
        ResultSet rs = con.executeQuery(dto.findById());
        try {
            while (rs.next()) {
                newObject = dataForObject(rs, newObject);
            }
        } catch (SQLException e) {
        }
        return newObject;
    }

    public List<IDto> getAll() {
        ResultSet rs = con.executeQuery(newObject().findAll());
        List<IDto> allData = new LinkedList<>();
        try {
            while (rs.next()) {
                T newObject = newObject();
                newObject = dataForObject(rs, newObject);
                allData.add(newObject);
            }
        } catch (SQLException e) {
        }
        return new ArrayList<IDto>(allData);
    }

    private T dataForObject(ResultSet rs, T newObject) {
        try {
            ResultSetMetaData metaData = rs.getMetaData();
            for (int i = 1; i <= metaData.getColumnCount(); i++) {
                String nameMethodSet = getNameSet(metaData.getColumnName(i)); // recupero nombre columna id y armo el nombre del metodo set setId
                Method methodToExecute = entityClass.getMethod(nameMethodSet, Class.forName(metaData.getColumnClassName(i)));
                methodToExecute.invoke(newObject, rs.getObject(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return newObject;
    }

    public T newObject() {
        T newObject = null;
        try {
            newObject = entityClass.getConstructor().newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return newObject;
    }

    protected Field[] getFields() {
        return entityClass.getFields();
    }

    private String setFirstLetterToUpperCase(String word){
        return Character.toUpperCase(word.charAt(0)) + word.substring(1);
    }

    private String getNameSet(String columnName) {
        while(columnName.indexOf("_") > 0){
            int pos = columnName.indexOf("_");
            columnName = columnName.substring(0,pos) +
                    setFirstLetterToUpperCase(columnName.substring(pos +1));
        }
        return "set"+setFirstLetterToUpperCase(columnName.substring(0));
    }

}

