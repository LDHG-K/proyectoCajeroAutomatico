package tiposCuentas;

import interfaces.AbstractDao;

public class tipos_cuentasDao extends AbstractDao<tipos_cuentas>

{
    public tipos_cuentasDao()
    {
        super(tipos_cuentas.class);
    }

}
