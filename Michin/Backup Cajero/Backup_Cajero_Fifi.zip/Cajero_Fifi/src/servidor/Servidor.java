package servidor;

import java.net.ServerSocket;
import java.net.Socket;


public class Servidor
{
    private final int puerto = 2027;
    private final int noConexiones = 20;

    public void escuchar()
    {
        try
        {
            ServerSocket servidor = new ServerSocket(puerto,noConexiones);

            while(true)
            {
                System.out.println("Conectado...");

                Socket cliente = servidor.accept();
                Runnable run = new HiloServidor(cliente);
                Thread hilo = new Thread(run);

                hilo.start();
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        
    }
    
    public static void main(String[] args)
    {
        Servidor servidor= new Servidor();
        servidor.escuchar();
    }
}
