package tiposIdentificaciones;

import interfaces.AbstractDao;

public class tipos_identificacionesDao extends AbstractDao<tipos_identificaciones>
{

    public tipos_identificacionesDao()
    {
        super(tipos_identificaciones.class);
    }
}
