package interfazGrafica;

import ServicioCliente.ServicioCliente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Saldo extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JLabel lblSu;
	private JTextField textField_1;
	ServicioCliente cliente = new ServicioCliente(Login.idCliente);

	
	/**
	 * Create the frame.
	 */
	public Saldo() {
		setTitle("CONSULTA");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 420, 193);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnSalir = new JButton("Atras");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				dispose();

			}
		});
		btnSalir.setBounds(170, 126, 97, 25);
		contentPane.add(btnSalir);




		JLabel lblSaldo = new JLabel("Su Saldo Es: " +  cliente.getSaldo());
		lblSaldo.setFont(new Font("Yrsa Medium", Font.PLAIN, 20));
		lblSaldo.setBounds(120, 68, 180, 32);
		contentPane.add(lblSaldo);
		

		
		lblSu = new JLabel("Bienvenide: " + cliente.getNombre());
		lblSu.setHorizontalAlignment(SwingConstants.CENTER);
		lblSu.setFont(new Font("Yrsa Medium", Font.BOLD, 28));
		lblSu.setBounds(40, 17, 337, 30);
		contentPane.add(lblSu);
		






	}
}
