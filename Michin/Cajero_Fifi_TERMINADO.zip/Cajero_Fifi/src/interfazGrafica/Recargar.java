package interfazGrafica;

import ServicioCliente.ServicioCliente;
import clientes.clientes;
import clientes.clientesDao;
import interfaces.abstractDao;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;

public class Recargar extends JFrame {

	private JPanel contentPane;
	private JTextField txtNumeroCuenta;
	private JTextField txtValorIngresado;
	private JButton btnVolver;
	private JButton btnIngresar;
	private JLabel lblConsignacion;

	

	/**
	 * Create the frame.
	 */
	public Recargar() {
		setTitle("CONSIGNACION");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 460, 256);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNumeoDeCuenta = new JLabel("# De Cuenta:");
		lblNumeoDeCuenta.setFont(new Font("Tlwg Typist", Font.BOLD, 17));
		lblNumeoDeCuenta.setBounds(39, 69, 136, 16);
		contentPane.add(lblNumeoDeCuenta);

		JLabel lblValorAIngresar = new JLabel("Valor:");
		lblValorAIngresar.setFont(new Font("Tlwg Typist", Font.BOLD, 17));
		lblValorAIngresar.setBounds(69, 125, 136, 16);
		contentPane.add(lblValorAIngresar);

		txtNumeroCuenta = new JTextField();
		txtNumeroCuenta.setBounds(193, 66, 221, 22);
		contentPane.add(txtNumeroCuenta);
		txtNumeroCuenta.setColumns(10);

		txtValorIngresado = new JTextField();
		txtValorIngresado.setColumns(10);
		txtValorIngresado.setBounds(193, 122, 221, 22);
		contentPane.add(txtValorIngresado);
		
		btnVolver = new JButton("Volver");
		btnVolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				dispose();
			}
		});
		btnVolver.setBounds(63, 171, 97, 25);
		contentPane.add(btnVolver);
		
		btnIngresar = new JButton("Ingresar");
		btnIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{

				String numeroCuenta = txtNumeroCuenta.getText().trim();
				BigDecimal dineroExtra = new BigDecimal (txtValorIngresado.getText());

				clientesDao clientesDaoObject = new clientesDao();

				ServicioCliente cliente = new ServicioCliente(numeroCuenta, null);

				BigDecimal dineroActual = abstractDao.saldo;

				dineroActual = dineroActual.add(dineroExtra);

				clientes clientesObject = new clientes(abstractDao.idCliente, abstractDao.clave, abstractDao.identificacion,abstractDao.nombres, abstractDao.apellidos,
						String.valueOf(abstractDao.cuenta), dineroActual,abstractDao.tipoIdentificacion,abstractDao.tipoCuenta, abstractDao.estadoTipo);

				clientesDaoObject.update(clientesObject);

				JOptionPane.showMessageDialog(null,"Ha Ingresado Correctamente: "+ txtValorIngresado.getText() +" Su nuevo saldo es: "
						+ dineroActual );

				dispose();

			}
		});
		btnIngresar.setBounds(235, 171, 97, 25);
		contentPane.add(btnIngresar);

		lblConsignacion = new JLabel("CONSIGNACION:");
		lblConsignacion.setHorizontalAlignment(SwingConstants.CENTER);
		lblConsignacion.setFont(new Font("Yrsa Medium", Font.BOLD, 30));
		lblConsignacion.setBounds(54, 12, 337, 29);
		contentPane.add(lblConsignacion);
	}

}
