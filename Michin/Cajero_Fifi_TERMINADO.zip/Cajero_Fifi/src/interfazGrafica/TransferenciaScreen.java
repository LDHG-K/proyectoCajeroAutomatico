package interfazGrafica;

import ServicioCliente.ServicioCliente;
import clientes.clientes;
import clientes.clientesDao;
import interfaces.abstractDao;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
public class TransferenciaScreen extends JFrame {

	private JPanel contentPane;
	private JTextField txtCuentaDestino;
	private JTextField textFieldValor;

	

	/**
	 * Create the frame.
	 */
	public TransferenciaScreen()
	{
		setTitle("Transferencias");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 487, 200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);


		JLabel lblNumeroDeCuenta_1 = new JLabel("Cuenta Destino: ");
		lblNumeroDeCuenta_1.setFont(new Font("Tlwg Typist", Font.BOLD, 18));
		lblNumeroDeCuenta_1.setBounds(35, 32, 214, 16);
		contentPane.add(lblNumeroDeCuenta_1);


		txtCuentaDestino = new JTextField();
		txtCuentaDestino.setBounds(255, 29, 190, 22);
		contentPane.add(txtCuentaDestino);
		txtCuentaDestino.setColumns(10);


		JLabel lblValorDeLa = new JLabel("Monto A Transferir: ");
		lblValorDeLa.setFont(new Font("Tlwg Typist", Font.BOLD, 17));
		lblValorDeLa.setBounds(35, 85, 202, 16);
		contentPane.add(lblValorDeLa);


		textFieldValor = new JTextField();
		textFieldValor.setBounds(255, 82, 190, 22);
		contentPane.add(textFieldValor);
		textFieldValor.setColumns(10);


		JButton btnTransferir = new JButton("Transferir");
		btnTransferir.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				clientesDao clientesDaoObject1 = new clientesDao();
				clientesDao clientesDaoObject2 = new clientesDao();

				BigDecimal dineroExtra = new BigDecimal(textFieldValor.getText());
				BigDecimal dineroActualRemitente = abstractDao.saldo;

				if(dineroActualRemitente.compareTo(dineroExtra) == 1)
				{
					dineroActualRemitente = dineroActualRemitente.subtract(dineroExtra);

					clientes clientesObject1 = new clientes(Principal.idCliente, abstractDao.clave, abstractDao.identificacion,
							abstractDao.nombres, abstractDao.apellidos,	String.valueOf(abstractDao.cuenta),
							dineroActualRemitente,abstractDao.tipoIdentificacion,abstractDao.tipoCuenta, abstractDao.estadoTipo);

					clientesDaoObject1.update(clientesObject1);

					//Aqui le suma al que recibe

					String numeroCuenta = txtCuentaDestino.getText().trim();
					BigDecimal dineroNuevo = new BigDecimal (textFieldValor.getText());

					ServicioCliente cliente = new ServicioCliente(numeroCuenta, null);

					BigDecimal dineroActualRecibe = abstractDao.saldo;
					dineroActualRecibe = dineroActualRecibe.add(dineroNuevo);

					clientes clientesObject2 = new clientes(abstractDao.idCliente, abstractDao.clave, abstractDao.identificacion,
							abstractDao.nombres, abstractDao.apellidos, String.valueOf(abstractDao.cuenta),
							dineroActualRecibe, abstractDao.tipoIdentificacion,abstractDao.tipoCuenta, abstractDao.estadoTipo);

					clientesDaoObject2.update(clientesObject2);

					ServicioCliente clienteRefresh = new ServicioCliente(Principal.idCliente);

					JOptionPane.showMessageDialog(null, "Transferencia Realizada Satisfactoriamente");

					dispose();
				}
				else
					{
					JOptionPane.showMessageDialog(null, "Fondos Insuficientes");
					}
			}
		});
		btnTransferir.setBounds(73, 120, 114, 35);
		contentPane.add(btnTransferir);

		JButton btnVolvt = new JButton("Volver");
		btnVolvt.setFont(new Font("Tlwg Typist", Font.BOLD, 14));
		btnVolvt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				dispose();
			}
		});

		btnVolvt.setBounds(278, 120, 97, 35);
		contentPane.add(btnVolvt);
	}

}
