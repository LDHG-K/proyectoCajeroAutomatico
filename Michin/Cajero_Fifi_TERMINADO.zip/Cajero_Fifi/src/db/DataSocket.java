package db;

import java.io.Serializable;

public class DataSocket implements Serializable {
    private static final long serialVersionUID = 3l;

    private Operation operation;
    private  Class entityClass;
    private String sql;

    public DataSocket(Operation operation, Class entityClass, String sql){
        this.operation = operation;
        this.entityClass = entityClass;
        this.sql = sql;

    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation){
        this.operation = operation;
    }

    public Class getEntityClass(){
        return entityClass;
    }

    public void setEntityClass(Class entityClass){
        this.entityClass = entityClass;
    }

    public String getSql(){
        return sql;
    }

    public void setSql(String sql){
        this.sql = sql;
    }

}
