package tiposIdentificaciones;

import interfaces.abstractDao;

public class tiposIdentificacionesDao extends abstractDao<tiposIdentificaciones>
{

    public tiposIdentificacionesDao()
    {
        super(tiposIdentificaciones.class);
    }
}
