package transacciones;

import interfaces.IDto;

import java.io.Serializable;
import java.time.LocalDateTime;

public class transacciones implements IDto, Serializable
{
    private static final long serialVersionUID = 1234592356L;

    private Integer transaccion_id;
    private Integer cliente_id;
    private LocalDateTime fecha;
    private Character movimiento;
    private Double valor;

    public transacciones (Integer transaccion_id, Integer cliente_id, LocalDateTime fecha, Character movimiento, Double valor)
    {
        this.transaccion_id = transaccion_id;
        this.cliente_id= cliente_id;
        this.fecha = fecha;
        this.movimiento = movimiento;
        this.valor = valor;
    }

    public transacciones()
    {
    }


    public Integer getTransaccion_id()
    {
        return this.transaccion_id;
    }

    public Integer getCliente_id()
    {
        return this.cliente_id;
    }

    public LocalDateTime getFecha()
    {
        return this.fecha;
    }

    public Character getMovimiento()
    {
        return this.movimiento;
    }

    public Double getValor()
    {
        return this.valor;
    }

    public void setTransaccion_id(Integer transaccion_id)
    {
        this.transaccion_id = transaccion_id;
    }

    public void setCliente_id(Integer cliente_id)
    {
        this.cliente_id = cliente_id;
    }

    public void setFecha(LocalDateTime fecha)
    {
        this.fecha = fecha;
    }

    public void setMovimiento(Character movimiento)
    {
        this.movimiento = movimiento;
    }

    public void setValor(Double valor)
    {
        this.valor = valor;
    }

    @Override
    public String insert()
    {
        return "insert into transacciones values("+getTransaccion_id()+","+getCliente_id()+",'"+getFecha()+"','"+getMovimiento()+"',"+getValor()+");"       ;
    }


    //En un banco o cajero jajas se actualizan transacciones que ya fueron creadas anteriormente.
    @Override
    public String update()
    {
        return null;
    }

    //En un banco o cajero las transacciones (Asi sean un error) jamas se eliminan.
    @Override
    public String delete()
    {
        return null;
    }

    @Override
    public String findAll()
    {
        return "select * from transacciones";
    }

    @Override
    public String findById()
    {
        return "select * from transacciones where transaccion_id = "+this.transaccion_id;
    }
}
