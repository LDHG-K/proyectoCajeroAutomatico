package transacciones;

import interfaces.abstractDao;

public class transacionesDao extends abstractDao<transacciones>
{
    public transacionesDao()
    {

        super(transacciones.class);
    }
}
