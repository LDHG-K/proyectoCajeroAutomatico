package estados;

import interfaces.IDto;

import java.io.Serializable;

public class estados implements IDto, Serializable
{

    private static final long serialVersionUID = 9891209481243L;


    private Integer tipo_estado;
    private String estado;



    public estados ()
    {

    }

    public estados (Integer tipo_estado, String estado)
    {
        this.tipo_estado = tipo_estado;
        this.estado = estado;
    }


    public Integer getTipo_estado()
    {
        return this.tipo_estado;
    }

    public String getEstado()
    {
        return this.estado;
    }

    public void setEstado(String estado)
    {
        this.estado = estado;
    }

    public void setTipo_estado(Integer tipo_estado)
    {
        this.tipo_estado = tipo_estado;
    }

    public String toString()
    {
        return "estados{" +  "tipo_estado=" + tipo_estado + ", estado='" + estado + '\'' +'}';
    }


    @Override
    public String insert()
    {
        return "insert into estados values("
                +getTipo_estado()+",'"+
                getEstado().trim()+"');"
                ;
    }

    @Override
    public String update()
    {
        return "update estados set estado = '"+getEstado().trim()+"' where tipo_estado = "+tipo_estado;
    }

    @Override
    public String delete() {
        return ("delete from estados where tipo_estado ="+tipo_estado);
    }

    @Override
    public String findAll() {
        return "select * from estados";
    }

    @Override
    public String findById() {
        return "select * from estados where tipo_estado = "+tipo_estado;
    }
}
