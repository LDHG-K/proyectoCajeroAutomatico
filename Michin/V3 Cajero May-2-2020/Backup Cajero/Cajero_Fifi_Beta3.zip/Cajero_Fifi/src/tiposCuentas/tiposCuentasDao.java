package tiposCuentas;

import interfaces.abstractDao;

public class tiposCuentasDao extends abstractDao<tiposCuentas>

{
    public tiposCuentasDao()
    {
        super(tiposCuentas.class);
    }

}
