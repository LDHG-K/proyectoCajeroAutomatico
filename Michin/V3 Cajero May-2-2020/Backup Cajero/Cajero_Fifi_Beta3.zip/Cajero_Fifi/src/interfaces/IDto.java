package interfaces;

public interface IDto

{
    public String insert();

    public String update();

    public String delete();

    public String findAll();

    public String findById();
}
