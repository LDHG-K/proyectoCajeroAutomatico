package login;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
//La clase HttpServlet, sirve para entender y comprender en peticiones y respuestas

// el @WebServlet = liga la clase loginServlet a login.do
@WebServlet(urlPatterns = "/login.do")

public class LoginServlet extends HttpServlet
{
    private LoginService userValidateService = new LoginService();


    //request es la peticion
    //en el response se arma la respuesta
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {

        String user= request.getParameter("user");
        request.setAttribute("user", user);
        request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        String user= req.getParameter("user");
        String password = req.getParameter("password");

        if(userValidateService.isUserValid(user, password))
        {
          //Aqui se crea un atributo de sesion para rescatarlo en cualquier servlet.

            req.getSession().setAttribute("user", user);
            resp.sendRedirect("principalc.do");
        }
        else{
            req.setAttribute("errorMessage", "Invalid_Credentials!");
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
        }

    }
}
