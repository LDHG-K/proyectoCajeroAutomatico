package login;

import Servicios.ServicioCliente;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
public class LoginService {

    public Integer idCliente;

    public boolean isUserValid(String user, String passowrd)
    {
        //String sql = "SELECT clave FROM public.clientes where cuenta = ? ;";

        Integer usuario = Integer.parseInt(user);

        idCliente = usuario;

        ServicioCliente cliente = new ServicioCliente(usuario);

        if (cliente.loginComprobacion(usuario,passowrd))
        {
            return true;
        }
        return false;
    }
}
