package Servicios;

import clientes.clientes;
import clientes.clientesDao;
import abstractOtro.abstractDao;

import javax.swing.*;

public class ServicioCliente
{

    public static Integer idCLiente;


    public ServicioCliente(Integer Usuario)
    {
        clientesDao clientesDaos = new clientesDao();
        clientes clientes = new clientes();

        clientesDaos.valoresFifis(Usuario);
        idCLiente = Usuario;

    }

    public ServicioCliente(String pCuenta, String hola)
    {
        clientesDao clientesDaos = new clientesDao();
        //clientes clientes = new clientes();

        clientesDaos.valoresFifisPorCuenta(pCuenta);

    }

    public ServicioCliente()
    {

    }

public boolean loginComprobacion (Integer user, String  claveEncriptada)
{
    String clave = claveEncriptada;

    Integer comprobacionUsuario = abstractDao.idCliente;
    Integer comprobacionClave = abstractDao.clave;
    System.out.println(comprobacionUsuario);
    System.out.println(comprobacionClave);

    if(user == comprobacionUsuario && clave.equals(String.valueOf(comprobacionClave)))
    {

        return true;
    }
    else
    {

        return false;
    }
}




public String getSaldo()
{
  return String.valueOf(abstractDao.saldo);
}

public Integer getIdCLiente ()
{
  return idCLiente;
}

public String getNombre ()
{
  return abstractDao.nombres;
}

public Integer getCuenta()
{
    return  abstractDao.cuenta;
}






}
