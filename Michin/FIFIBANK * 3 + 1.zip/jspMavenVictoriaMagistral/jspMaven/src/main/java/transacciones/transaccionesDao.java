package transacciones;

import abstractOtro.abstractDao;

public class transaccionesDao extends abstractDao<transacciones>
{
    public transaccionesDao()
    {

        super(transacciones.class);
    }
}
