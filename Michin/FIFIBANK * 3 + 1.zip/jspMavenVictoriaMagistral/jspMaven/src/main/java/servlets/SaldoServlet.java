package servlets;

import Servicios.ServicioCliente;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/saldo.do")
public class SaldoServlet extends HttpServlet {



    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        int variable = Integer.parseInt((String) req.getSession().getAttribute("user"));

        ServicioCliente cliente = new ServicioCliente(variable);

        String saldo = cliente.getSaldo();
        String nombre = cliente.getNombre();


        req.setAttribute("saldito",saldo);
        req.setAttribute("nombre",nombre);

        req.getRequestDispatcher("/WEB-INF/views/saldo.jsp").forward(req,resp);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {



    }
}
