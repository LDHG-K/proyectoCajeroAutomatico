package servlets;

import Servicios.ServicioCliente;
import abstractOtro.abstractDao;
import clientes.clientes;
import clientes.clientesDao;
import transacciones.transacciones;
import transacciones.transaccionesDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;

@WebServlet(urlPatterns = "/transferencia.do")
public class transferenciaServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {

        req.getRequestDispatcher("WEB-INF/views/transferencia.jsp").forward(req, resp);

        Integer id = Integer.parseInt((String) req.getSession().getAttribute("user"));
        clientesDao clientesDaoObject1 = new clientesDao();
        clientesDao clientesDaoObject2 = new clientesDao();

        BigDecimal dineroExtra = new BigDecimal(req.getParameter("valor"));

        BigDecimal dineroActualRemitente = abstractDao.saldo;

        String action = req.getParameter("boton");
        System.out.println(dineroActualRemitente);
        System.out.println(dineroExtra);
        if (action.equals("transferir")) {
            System.out.println("Entre");
            if (dineroActualRemitente.compareTo(dineroExtra) == 1) {
                dineroActualRemitente = dineroActualRemitente.subtract(dineroExtra);

                clientes clientesObject1 = new clientes(id, abstractDao.clave, abstractDao.identificacion,
                        abstractDao.nombres, abstractDao.apellidos, String.valueOf(abstractDao.cuenta),
                        dineroActualRemitente, abstractDao.tipoIdentificacion, abstractDao.tipoCuenta, abstractDao.estadoTipo);
                clientesDaoObject1.update(clientesObject1);
                //Aca Restamos la transaccion a la tabla transacciones
                transaccionesDao transaccionesDaoRestar = new transaccionesDao();
                Integer idRandom = (int) (Math.random() * 99999);
                transacciones transaccionRestar = new transacciones(idRandom, id, new Timestamp(System.currentTimeMillis()), "P", dineroExtra.negate());
                transaccionesDaoRestar.insert(transaccionRestar);
                //Aqui le suma al que recibe
                String numeroCuenta = req.getParameter("cuenta");
                System.out.println(numeroCuenta);
                BigDecimal dineroNuevo = new BigDecimal(req.getParameter("valor"));
                System.out.println(dineroNuevo);
                ServicioCliente cliente = new ServicioCliente(numeroCuenta, null);
                BigDecimal dineroActualRecibe = abstractDao.saldo;
                dineroActualRecibe = dineroActualRecibe.add(dineroNuevo);
                clientes clientesObject2 = new clientes(abstractDao.idCliente, abstractDao.clave, abstractDao.identificacion,
                        abstractDao.nombres, abstractDao.apellidos, String.valueOf(abstractDao.cuenta),
                        dineroActualRecibe, abstractDao.tipoIdentificacion, abstractDao.tipoCuenta, abstractDao.estadoTipo);

                clientesDaoObject2.update(clientesObject2);
                //Aca Sumamos la transaccion a la tabla transacciones
                transaccionesDao transaccionesDaoSumar = new transaccionesDao();
                Integer idRandom1 = (int) (Math.random() * 99999);
                transacciones transaccionSumar = new transacciones(idRandom1, abstractDao.idCliente, new Timestamp(System.currentTimeMillis()), "A", dineroNuevo);
                transaccionesDaoSumar.insert(transaccionSumar);
                ServicioCliente clienteRefresh = new ServicioCliente(id);

            }

            req.getRequestDispatcher("WEB-INF/views/transferencia.jsp").forward(req, resp);
        }
    }
}
