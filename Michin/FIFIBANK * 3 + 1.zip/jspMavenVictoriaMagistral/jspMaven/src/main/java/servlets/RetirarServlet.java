package servlets;

import Servicios.ServicioCliente;
import abstractOtro.abstractDao;
import clientes.clientes;
import clientes.clientesDao;
import transacciones.transacciones;
import transacciones.transaccionesDao;
import java.lang.System;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;


@WebServlet(urlPatterns = "/retirar.do")
public class RetirarServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {

        Integer id = Integer.parseInt((String) req.getSession().getAttribute("user"));
        ServicioCliente cliente = new ServicioCliente(id);

        String saldoTotal = cliente.getSaldo();
        req.setAttribute("saldito",saldoTotal);


        req.getRequestDispatcher("/WEB-INF/views/retirar.jsp").forward(req,resp);


        Double total =  Double.parseDouble(cliente.getSaldo());
        Double retiro = Double.parseDouble(req.getParameter("retiro"));

        Double resultado = total - retiro;

        BigDecimal saldo = new BigDecimal (resultado);
        clientes clientesObject = new clientes(id, abstractDao.clave, abstractDao.identificacion, abstractDao.nombres, abstractDao.apellidos,
                String.valueOf(abstractDao.cuenta), saldo, abstractDao.tipoIdentificacion, abstractDao.tipoCuenta, abstractDao.estadoTipo);
        clientesDao clientesDaoObject = new clientesDao();
        clientesDaoObject.update(clientesObject);
        //Aca Restamos la transaccion a la tabla transacciones

        transaccionesDao transaccionesDao = new transaccionesDao ();
        Integer idRandom = (int)(Math.random()*99999);
        String valor = req.getParameter("retiro");

        BigDecimal dineroARetirar = new BigDecimal (valor);
        transacciones transaccion = new transacciones(idRandom,id,new Timestamp(System.currentTimeMillis()), "P",  dineroARetirar.negate());
        clientes clienteNuevoSaldo = new clientes();



            transaccionesDao.insert(transaccion);

            req.getRequestDispatcher("/WEB-INF/views/retirar.jsp").forward(req,resp);


    }



    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

    }
}
