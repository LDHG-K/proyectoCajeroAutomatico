package clientes;

import abstractOtro.abstractDao;

public class clientesDao  extends abstractDao<clientes>
{
    public clientesDao()
    {
        super(clientes.class);
    }
}
