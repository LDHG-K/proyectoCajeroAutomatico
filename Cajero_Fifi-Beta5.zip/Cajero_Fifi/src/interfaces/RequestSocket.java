package interfaces;

import db.DataSocket;

import java.io.ObjectOutputStream;
import java.io.Serializable;

public abstract class RequestSocket implements Serializable {

private static final long serialVersionUID = 1929781818775797L;

protected DataSocket request;
protected ObjectOutputStream oos;

protected RequestSocket ( DataSocket request){
    this.request = request;
}

public abstract boolean executeRequest();

public void setOos(ObjectOutputStream oos){
    this.oos = oos;
}


}
