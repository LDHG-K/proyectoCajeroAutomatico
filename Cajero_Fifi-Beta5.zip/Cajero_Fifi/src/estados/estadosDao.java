package estados;

import interfaces.abstractDao;

public class estadosDao extends abstractDao<estados>
{


    public estadosDao()
    {
        super(estados.class);
    }
}
