import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class Retirar extends JFrame {

	private JPanel contentPane;
	private JTextField txtRetirar;
	private JButton btnRetirar;
	private JButton btnVolver;
	private JTextField txtSaldo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Retirar frame = new Retirar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Retirar() {
		setTitle("Cajero FIFI");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 323);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Saldo");
		lblNewLabel.setFont(new Font("Tahoma", Font.ITALIC, 16));
		lblNewLabel.setBounds(12, 160, 56, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblCuantoDeseaRetirar = new JLabel("Cuanto desea retirar");
		lblCuantoDeseaRetirar.setHorizontalAlignment(SwingConstants.CENTER);
		lblCuantoDeseaRetirar.setFont(new Font("Tahoma", Font.ITALIC, 14));
		lblCuantoDeseaRetirar.setBounds(12, 53, 131, 33);
		contentPane.add(lblCuantoDeseaRetirar);
		
		txtRetirar = new JTextField();
		txtRetirar.setBounds(166, 59, 228, 22);
		contentPane.add(txtRetirar);
		txtRetirar.setColumns(10);
		
		btnRetirar = new JButton("Retirar");
		btnRetirar.setBounds(12, 238, 97, 25);
		contentPane.add(btnRetirar);
		
		btnVolver = new JButton("Volver");
		btnVolver.setBounds(323, 238, 97, 25);
		contentPane.add(btnVolver);
		
		txtSaldo = new JTextField();
		txtSaldo.setColumns(10);
		txtSaldo.setBounds(166, 158, 228, 22);
		contentPane.add(txtSaldo);
	}

}
