package clientes;

import interfaces.IDto;

import java.io.Serializable;
import java.math.BigDecimal;

public class clientes implements IDto, Serializable
{
    //-------------------------------
    private static final long serialVersionUID = 9891209481243L;
    private Integer idCliente ;
    private Integer clave;
    private String identificacion;
    private String nombres;
    private String apellido;
    private String cuenta;
    private BigDecimal saldo;
    private Integer tipoIdentificacion;
    private Integer tipoCuenta;
    private Integer estadoTipo;

    //--------------------------------
 public clientes (Integer idcliente, Integer clave, String identificacion, String nombres, String  apellido, String cuenta, BigDecimal saldo, Integer tipoIdentificacion, Integer tipoCuenta, Integer estadoTipo){

     this.idCliente = idcliente ;
     this.clave = clave;
     this.identificacion = identificacion;
     this.apellido = apellido;
     this.nombres = nombres;
     this.cuenta = cuenta;
     this.saldo = saldo;
     this.tipoIdentificacion=tipoIdentificacion;
     this.tipoCuenta= tipoCuenta;
     this.estadoTipo=estadoTipo;
 }
 public clientes (Integer idCliente) {this.idCliente = idCliente;}

 public clientes () { }
    //-------------------------------------

    public Integer getIdCliente()
    {
        return this.idCliente;
    }

    public void setIdCliente(Integer idCliente)
    {
        this.idCliente = idCliente;
    }

    public Integer getClave()
    {
        return this.clave;
    }

    public void setClave(Integer clave)
    {
        this.clave = clave;
    }

    public String getIdentificacion()
    {
        return identificacion;
    }

    public void setIdentificacion(String identificacion)
    {
        this.identificacion = identificacion;
    }

    public String getNombre()
    {
        return this.nombres;
    }

    public void setNombres(String nombre)
    {
        this.nombres = nombre;
    }

    public String getApellido()
    {
        return apellido;
    }

    public void setApellidos(String apellido)
    {
        this.apellido = apellido;
    }

    public String getCuenta()
    {
        return cuenta;
    }

    public void setCuenta(String cuenta)
    {
        this.cuenta = cuenta;
    }

    public BigDecimal getSaldo()
    {
        return saldo;
    }

    public void setSaldo(BigDecimal saldo)
    {
        this.saldo = saldo;
    }

    public Integer getTipoIdentificacion()
    {
        return tipoIdentificacion;
    }

    public void setTipoIdentificacion(Integer tipoIdentificacion)
    {
        this.tipoIdentificacion = tipoIdentificacion;
    }

    public Integer getTipoCuenta()
    {
        return tipoCuenta;
    }

    public void setTipoCuenta(Integer tipoCuenta)
    {
        this.tipoCuenta = tipoCuenta;
    }

    public Integer getEstadoTipo()
    {
        return estadoTipo;
    }

    public void setEstadoTipo(Integer estadoTipo)
    {
        this.estadoTipo = estadoTipo;
    }

    //--------------------------------------
    @Override
    public String insert() {
        return "insert into clientes values ("+getIdCliente()+","+getIdentificacion()+","+getNombre()+","+getApellido()+","+getCuenta()+","+getSaldo()+","+
                getTipoIdentificacion()+","+getTipoCuenta()+","+getEstadoTipo()+");";
    }

    @Override
    public String update()
    {
        return "update clientes set cuenta =" + getCuenta() +
                ", nombres='" + getNombre() +
                "', apellidos='" +getApellido()+
                "', clave="+getClave()+
                ", identificacion="+getIdentificacion()+
                ", saldo="+getSaldo()+
                ", tipo_identificacion="+getTipoIdentificacion()+
                ", tipo_cuenta="+getTipoCuenta()+
                ", estado_tipo="+getEstadoTipo()+

                "where id_cliente =" + getIdCliente() +";";
    }

    @Override
    public String delete()
    {
        return "delete from clientes where id_cliente ="+getIdCliente()+";";
    }

    @Override
    public String findAll()
    {
        return "select * from clientes;";
    }

    @Override
    public String findById() {
        return "select * from clientes where id_cliente = "+getIdCliente()+";";
    }
//-----------------------------------------

    @Override
    public String toString() {
        return "clientes{" +
                "idCliente=" + idCliente +
                ", clave=" + clave +
                ", identificacion=" + identificacion +
                ", nombre='" + nombres + '\'' +
                ", apellido='" + apellido + '\'' +
                ", cuenta=" + cuenta +
                ", saldo=" + saldo +
                ", tipoIdentificacion=" + tipoIdentificacion +
                ", tipoCuenta=" + tipoCuenta +
                ", estadoCuenta=" + estadoTipo +
                '}' + "\n";
    }
}
