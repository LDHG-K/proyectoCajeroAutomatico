package interfaces;

import db.DataSocket;
import servidor.executeSql;

public class MultipleResult extends RequestSocket{


    public MultipleResult (DataSocket request){
        super(request);
    }



    public boolean executeRequest(){
        try{
            Class classIDto = Class.forName(request.getEntityClass().getName());      // puede ser IdClientes
            executeSql<IDto> executeSql = new executeSql<IDto>(classIDto);
            IDto response = (IDto) executeSql.getManyResults(request.getSql());
            oos.writeObject(response);

        } catch (Exception e){

            e.printStackTrace();
        }
        return true;
    }


}
