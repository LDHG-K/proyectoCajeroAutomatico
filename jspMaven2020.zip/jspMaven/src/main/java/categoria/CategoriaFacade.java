package categoria;

import java.sql.SQLException;

public class CategoriaFacade {

		private CategoriaDao dao;
		
		public CategoriaFacade() {
			dao = new CategoriaDao();
		}
		
		public Object[] getNameBrands() throws SQLException {
			return dao.getNameBrands();
		}
		
		public int getVehicleBrandKey(String nombre) throws SQLException {
			return dao.getCategoriasKey(nombre);
		}

}
