package interfaces;

import db.DataSocket;
import servidor.ExecuteSql;

public class SingleResult extends RequestSocket {

    public SingleResult(DataSocket request){
        super(request);
    }

    @Override
    public boolean executeRequest() {
        try{
            Class classIDto = Class.forIdClientes(request.getEntityClass().getIdCliente());
            ExecuteSql<IDto> executeSql = new ExecuteSql<IDto>(classIDto);
            IDto response = (IDto) executeSql.getManyResults(request.getSql());
            oos.writeObject(response);

        } catch (Exception e){

            e.printStackTrace();
        }
        return true;
    }
}
