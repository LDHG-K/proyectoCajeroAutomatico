package ServicioCliente;

import clientes.clientes;
import clientes.clientesDao;
import interfaces.abstractDao;

import javax.swing.*;

public class ServicioCliente
{

    public static Integer idCLiente;


    public ServicioCliente(Integer Usuario)
    {
        clientesDao clientesDaos = new clientesDao();
        clientes clientes = new clientes();

        clientesDaos.valoresFifis(Usuario);
        idCLiente = Usuario;

    }

    public ServicioCliente(String pCuenta, String hola)
    {
        clientesDao clientesDaos = new clientesDao();
        //clientes clientes = new clientes();

        clientesDaos.valoresFifisPorCuenta(pCuenta);

    }

    public ServicioCliente()
    {

    }

public boolean loginComprobacion (Integer user, char [] claveEncriptada)
{
    String clave = new String(claveEncriptada);

    Integer comprobacionUsuario = abstractDao.idCliente;
    Integer comprobacionClave = abstractDao.clave;

    if(user == comprobacionUsuario && clave.equals(String.valueOf(comprobacionClave)))
    {
        JOptionPane.showMessageDialog(null,"Bienvenide Estimade: "+ abstractDao.nombres);
        return true;
    }
    else
    {
        return false;
    }
}




public String getSaldo()
{
  return String.valueOf(abstractDao.saldo);
}

public Integer getIdCLiente ()
{
  return idCLiente;
}

public String getNombre ()
{
  return abstractDao.nombres;
}

public Integer getCuenta()
{
    return  abstractDao.cuenta;
}






}
