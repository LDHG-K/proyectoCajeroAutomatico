package interfazGrafica;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CajeroPrincipal extends JFrame {

	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	public CajeroPrincipal() {
		setTitle("Cajero FIFI");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 210);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblBienvenido = new JLabel("Bienvenido FIFI Bank");
		lblBienvenido.setHorizontalAlignment(SwingConstants.CENTER);
		lblBienvenido.setFont(new Font("Yrsa Medium", Font.BOLD, 30));
		lblBienvenido.setBounds(25, 12, 337, 29);
		contentPane.add(lblBienvenido);
		


		JButton btnConsultarSaldo = new JButton("Consultar saldo");
		btnConsultarSaldo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				final Saldo graf = new Saldo();
				graf.setVisible(true);

			}
		});
		btnConsultarSaldo.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnConsultarSaldo.setBounds(12, 79, 132, 33);
		contentPane.add(btnConsultarSaldo);
		
		JButton btnConsultarsaldo_1 = new JButton("Salir");
		btnConsultarsaldo_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}
		});
		btnConsultarsaldo_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnConsultarsaldo_1.setBounds(12, 134, 132, 33);
		contentPane.add(btnConsultarsaldo_1);
		


		JButton btnRetirar = new JButton("Retirar");
		btnRetirar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				final Retirar retir = new Retirar();
				retir.setVisible(true);
			}
		});
		btnRetirar.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnRetirar.setBounds(244, 134, 132, 33);
		contentPane.add(btnRetirar);
		


		JButton btnTransferencia = new JButton("Transferencia");
		btnTransferencia.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				TransferenciaScreen nueva = new TransferenciaScreen();
				nueva.setVisible(true);
			}
		});
		btnTransferencia.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnTransferencia.setBounds(244, 79, 132, 33);
		contentPane.add(btnTransferencia);
	}
}
