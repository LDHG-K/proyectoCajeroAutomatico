package login;


import todo.TodoService;
import categoria.Categoria;
import categoria.CategoriaDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.SQLOutput;
import java.util.ArrayList;
//La clase HttpServlet, sirve para entender y comprender en peticiones y respuestas

// el @WebServlet = liga la clase loginServlet a login.do
@WebServlet(urlPatterns = "/login.do")

public class LoginServlet extends HttpServlet
{
    private LoginService userValidateService = new LoginService();
    private TodoService todoService= new TodoService();
    private CategoriaDao brandDao = new CategoriaDao();

    //request es la peticion
    //en el response se arma la respuesta
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {


//        try
//        {
//            ArrayList<Categoria> probador = (ArrayList<Categoria>) brandDao.getAll();
//
//            for (int i =0; i<probador.size();i++)
//            {
//                System.out.println(probador.get(i).getName());
//            }
//        }
//        catch (SQLException throwables)
//        {
//            throwables.printStackTrace();
//        }




        String user= request.getParameter("user");
        request.setAttribute("user", user);
        request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);

        /*
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>My First Servlet</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("My first Servlet");
        out.println("</body>");
        out.println("</<html>");
        */


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
       String user= req.getParameter("user");
       String password = req.getParameter("password");

       if(userValidateService.isUserValid(user, password))
       {
         /*  req.setAttribute("user", user);
           req.setAttribute("todos", todoService.retriveTodos());
            req.getRequestDispatcher("/WEB-INF/views/Welcome.jsp").forward(req, resp);
            */

           //Aqui se crea un atributo de sesion para rescatarlo en cualquier servlet
           req.getSession().setAttribute("user", user);
           resp.sendRedirect("todo.do");
        }
        else{
            req.setAttribute("errorMessage", "Invalid_Credentials!");
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
            }

    }
}
