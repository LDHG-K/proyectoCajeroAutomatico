package login;

public class LoginService {

    public boolean isUserValid(String user, String passowrd){

        if(user.equals("FIFIBANK") && passowrd.equals("1234")){
            return true;
        }
        return false;
    }
}
