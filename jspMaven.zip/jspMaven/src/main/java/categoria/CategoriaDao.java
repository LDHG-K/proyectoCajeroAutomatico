package categoria;

import abstracts.AbstractDao;
import interfaces.IDto;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

public class CategoriaDao extends AbstractDao<Categoria> {

	@Override
	public Categoria getById(IDto dto) throws SQLException {
		ResultSet rs = con.executeQuery(dto.findById());
		Categoria categoria = null;
		while (rs.next()) {
			categoria = new Categoria(rs.getInt("id"), rs.getString(2));
		}
		return categoria;
	}

	@Override
	public Collection<Categoria> getAll() throws SQLException {
		ResultSet rs = con.executeQuery((new Categoria()).findAll());
		List<Categoria> categorias = new LinkedList<Categoria>();
		while (rs.next()) {
			categorias.add(new Categoria(rs.getInt("id"), rs.getString(2)));
		}
		return new ArrayList<Categoria>(categorias);
	}

	public String[] getNameBrands() throws SQLException {
		ResultSet rs = con.executeQuery("Select nombre from public.categorias order by nombre;");
		List<String> vehiclesBrands = new LinkedList<String>();
		while (rs.next()) {
			vehiclesBrands.add(rs.getString(1).trim());
		}
		return vehiclesBrands.stream().toArray(String[]::new);
	}

	public int getCategoriasKey(String name) throws SQLException {
		ResultSet rs = con.executeQuery("Select id from public.categorias where nombre = '" + name.trim() + "';");
		int id = 0;
		while (rs.next()) {
			id = rs.getInt(1);
		}
		return id;
	}

}
