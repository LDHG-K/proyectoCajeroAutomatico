package categoria;
//vehicles_brands


import interfaces.IDto;

public class Categoria implements IDto {
	//created_at updated_at
	private Integer id;
	private String nombre;	
	public Categoria() {
	}
	
	public Categoria(Integer id) {
		this.id = id;
	}
	
	public Categoria(Integer id, String name) {
		super();
		this.id = id;
		this.nombre = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return nombre;
	}

	public void setName(String name) {
		this.nombre = name;
	}

	@Override
	public String insert() {
		return "INSERT into public.categorias(id,nombre) values("+getId()
		+", '"+getName().trim()+"');";
	}

	@Override
	public String update() {
		return "UPDATE public.categorias set nombre = '"+getName().trim()+
				"' where id = "+getId();
	}

	@Override
	public String delete() {
		return "DELETE FROM public.categorias where id = "+getId();
	}

	@Override
	public String findAll() {
		return "SELECT id, nombre FROM public.categorias;";
	}

	@Override
	public String findById() {
		return "SELECT id, nombre FROM public.categorias where id = "+getId();
	}
	
	
	
}
