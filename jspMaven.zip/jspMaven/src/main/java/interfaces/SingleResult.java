package interfaces;

import db.DataSocket;
import servidor.executeSql;

public class SingleResult extends RequestSocket {

    public SingleResult(DataSocket request){
        super(request);
    }

    @Override
    public boolean executeRequest() {
        try{
            Class classIDto = Class.forName(request.getEntityClass().getName());
            executeSql<IDto> executeSql = new executeSql<IDto>(classIDto);
            IDto response = (IDto) executeSql.getManyResults(request.getSql());
            oos.writeObject(response);

        } catch (Exception e){

            e.printStackTrace();
        }
        return true;
    }
}
