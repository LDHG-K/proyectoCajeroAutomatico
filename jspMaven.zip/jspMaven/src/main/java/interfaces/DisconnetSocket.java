package interfaces;

import db.DataSocket;

public class DisconnetSocket extends RequestSocket {

        public DisconnetSocket(DataSocket request)
        {
            super(request);
        }

        @Override
        public boolean executeRequest() {
            try {
                oos.writeObject("Desconexion esta activa");
            } catch (Exception e) {
                e.printStackTrace();
            }
            return false;
        }
    }

