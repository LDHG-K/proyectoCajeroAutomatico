package categoriaTable;

import categoria.Categoria;
import categoria.CategoriaDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;


@WebServlet(urlPatterns = "/categorias.do")

public class CategoriaServlet extends HttpServlet
{

    private CategoriaDao brandDao = new CategoriaDao();
    private Categoria cateNuevo = new Categoria();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        String action = req.getParameter("accion");
        try
        {
            ArrayList<Categoria> probador = (ArrayList<Categoria>) brandDao.getAll();
            req.setAttribute("brands", probador);
            req.getRequestDispatcher("/WEB-INF/views/brands.jsp").forward(req,resp);
            System.out.println(action);
            for (int i =0; i<probador.size(); i++){
                System.out.println(probador.get(i).getName());
            }

        }
        catch (SQLException throwables)
        {
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req,resp);
        }
        if(action.equals("Agregar")){


        }
        else if (action.equals("Modificar")){
            
        }

    }
}
